<?php

use Faker\Generator as Faker;

$factory->define(App\Nilai::class, function (Faker $faker) {
    return [
        //
    ];
});
