<?php

use Faker\Generator as Faker;

$factory->define(App\Kriteria::class, function (Faker $faker) {
    return [
        //
    ];
});
