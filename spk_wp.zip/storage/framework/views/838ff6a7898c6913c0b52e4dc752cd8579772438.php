<?php $__env->startSection('title', 'Ubah Kriteria'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Ubah Kriteria
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(Route('kriteria.index')); ?>">Data Kriteria</a></li>
      <li class="active">Ubah Kriteria</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        
        <div class="box box-primary">
            <!-- form start -->
            <form enctype="multipart/form-data" class="bg-white shadow-sm p-3"
            action="<?php echo e(route('kriteria.update', ['id'=>$kriteria->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="PUT" name="_method">
              <div class="box-body">
                <div class="form-group">
                  <label for="nama">Nama Kriteria</label>
                  <input value="<?php echo e(old('nama') ? old('nama') : $kriteria->nama); ?>" class="form-control <?php echo e($errors->first('nama')
                    ? "is-invalid": ""); ?>" placeholder="Nama Kriteria" type="text" name="nama"
                    id="nama"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama')); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label for="atribut">Atribut</label>
                    <select name="atribut" class="form-control" id="atribut">
                        <option value=""></option>
                        <option value="benefit" <?php echo e($kriteria->atribut === "benefit" ? "selected" : ""); ?>>Benefit</option>
                        <option value="cost" <?php echo e($kriteria->atribut === "cost" ? "selected" : ""); ?>>Cost</option>
                    </select>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('atribut')); ?>

                    </div>
                </div>
                <div class="form-group">
                <label for="bobot">Bobot</label>
                <input value="<?php echo e(old('bobot') ? old('bobot') : $kriteria->bobot); ?>" class="form-control <?php echo e($errors->first('bobot')
                    ? "is-invalid": ""); ?>" placeholder="Bobot" type="text" name="bobot"
                    id="bobot"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('bobot')); ?>

                    </div>
                </div>
                <div class="form-group">
                  <label for="keterangan">Keterangan</label>
                  <input value="<?php echo e(old('keterangan') ? old('keterangan') : $kriteria->keterangan); ?>" class="form-control <?php echo e($errors->first('keterangan')
                      ? "is-invalid": ""); ?>" placeholder="Keterangan" type="text" name="keterangan"
                      id="keterangan"/>
                      <div class="invalid-feedback">
                          <?php echo e($errors->first('keterangan')); ?>

                      </div>
                  </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Ubah</button>
              </div>
            </form>
          </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>