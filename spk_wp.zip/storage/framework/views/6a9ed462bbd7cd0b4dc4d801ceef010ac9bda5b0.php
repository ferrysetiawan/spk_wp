<?php $__env->startSection('title', 'Penilaian Kandidat'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Penilaian Kandidat
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(Route('kandidat.index')); ?>">Data Kandidat</a></li>
      <li class="active">Penilaian Kandidat</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo e($title); ?></h3>
            </div>
            <div class="box-body">
                <form method="post" action="<?php echo e(url('nilai/create', ['id' => $penerima->id ])); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="penerima" value="<?php echo e($penerima->id); ?>"/>
                    <table class="table table-bordered">
                    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <strong><?php echo e($k->nama); ?></strong>
                            </td>
                            <td width="1%">
                                :
                            </td>
                            <td>
                                <input type="text" class="form-control" name="kriteria[<?php echo e($k->id); ?>]" value="<?php echo e((array_key_exists($k->id,$data)) ? $data[$k->id] : ''); ?>" placeholder="Nilai" pattern="[0-9]+(\.[0-9][0-9]?)?" />
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <button class="btn btn-info" type="submit">Simpan</button>
                </form>
              </div>
              <!-- /.box-body -->
            </div>
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>