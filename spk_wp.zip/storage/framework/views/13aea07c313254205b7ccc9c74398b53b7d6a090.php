<?php $__env->startSection('title', 'Detail Kandidat'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Detail Kandidat
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(Route('kandidat.index')); ?>">Data Kandidat</a></li>
      <li class="active">Detail Kandidat</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        
        <div class="box box-primary">
            <div class="box-body box-profile">
                <?php if($kandidat->foto): ?>
                    <img class="profile-user-img img-responsive"  src="<?php echo e(asset('storage/'.$kandidat->foto)); ?>" width="150px"/>
                <?php else: ?>
                    <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset('storage/default.png')); ?>" alt="User profile picture">
                <?php endif; ?>
                <h3 class="profile-username text-center"><?php echo e($kandidat->nama); ?></h3>
  
                <ul class="list-group list-group-unbordered">
                    <li class="list-group-item">
                        <b>Nip</b> <a class="pull-right"><?php echo e($kandidat->nip); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>Jenis Kelamin</b> <a class="pull-right"><?php echo e(($kandidat->jk == 'L') ? 'laki-laki' : 'perempuan'); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>Tanggal Lahir</b> <a class="pull-right"><?php echo e($kandidat->tanggal_lahir); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>Alamat</b> <a class="pull-right"><?php echo e($kandidat->alamat); ?></a>
                    </li>
                    <li class="list-group-item">
                        <b>No Telphone</b> <a class="pull-right"><?php echo e($kandidat->telp); ?></a>
                    </li>
                </ul>
            </div>
              <!-- /.box-body -->
          
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>