<?php $__env->startSection('title', 'Nilai Kandidat'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Nilai Kandidat
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Nilai Kandidat</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        
        <div class="box">
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                    <th width="20vh">No</th>
                    <th width="75vh">NIP</th>
                    <th>Nama</th>
                    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($krit->nama); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th width="100vh">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php if(!empty($kandidat)): ?>
                
                <?php $__currentLoopData = $kandidat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kdt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($kdt->nip); ?></td>
                    <td><?php echo e($kdt->nama); ?></td>
                    <?php if(count($kdt->nilai) == 0): ?>
                    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><i>Tidak ada data</i></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php $__currentLoopData = $kdt->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($nilai->nilai); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td class="text-center">
                        <?php if(count($kdt->nilai) == 0): ?>
                        <a href="<?php echo e(route('nilai.tambah',['id' => $kdt->id])); ?>" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="bottom" title="tambah data"><i class="fa fa-plus"></i>
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('nilai.edit', ['id' => $kdt->id])); ?>" class="btn btn-sm btn-warning" data-toggle="tooltip" data-placement="bottom" title="ubah data"><span class="glyphicon glyphicon-pencil"></span>
                        </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
            </table>
            <a href="<?php echo e(url('perhitungan/calculate')); ?>" class="margin-bottom-2 btn btn-primary btn-sm btn-rounded btn-fw"><span class="glyphicon glyphicon-eye-open"></span> Perhitungan MWP</a>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
<script>
  $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip()
  });
</script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>