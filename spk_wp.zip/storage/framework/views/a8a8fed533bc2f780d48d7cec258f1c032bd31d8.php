<?php $__env->startSection('title', 'Ubah Kandidat'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Ubah Kandidat
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(Route('kandidat.index')); ?>">Data Kandidat</a></li>
      <li class="active">Ubah Kandidat</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        
        <div class="box box-primary">
            <!-- form start -->
            <form enctype="multipart/form-data" class="bg-white shadow-sm p-3"
            action="<?php echo e(route('kandidat.update', ['id'=>$kandidat->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="PUT" name="_method">
              <div class="box-body">
                <div class="form-group">
                    <label for="nip">Nip</label>
                    <input readonly value="<?php echo e(old('nip') ? old('nip') : $kandidat->nip); ?>" class="form-control <?php echo e($errors->first('nip')
                    ? "is-invalid": ""); ?>" placeholder="Full Name" type="text" name="nip"
                    id="nip"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nip')); ?>

                    </div>

                </div>
                <div class="form-group">
                  <label for="nama">Nama</label>
                  <input value="<?php echo e(old('nama') ? old('nama') : $kandidat->nama); ?>" class="form-control <?php echo e($errors->first('nama')
                    ? "is-invalid": ""); ?>" placeholder="Full Name" type="text" name="nama"
                    id="nama"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama')); ?>

                    </div>

                </div>
                <div class="form-group">
                    <label for="jk">Jenis Kelamin</label>
                        <select name="jk" class="form-control" id="jk">
                            <option value=""></option>
                            <option value="L" <?php echo e($kandidat->jk === "L" ? "selected" : ""); ?>>Laki - Laki</option>
                            <option value="P" <?php echo e($kandidat->jk === "P" ? "selected" : ""); ?>>Perempuan</option>
                        </select>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('jk')); ?>

                    </div>
    
                </div>
                <div class="form-group">
                  <label for="tanggal_lahir">Tanggal Lahir</label>
                  <input value="<?php echo e(old('tanggal_lahir') ? old('tanggal_lahir') : $kandidat->tanggal_lahir); ?>" class="form-control <?php echo e($errors->first('tanggal_lahir')
                    ? "is-invalid": ""); ?>" type="date" name="tanggal_lahir"
                    id="tanggal_lahir"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tanggal_lahir')); ?>

                    </div>

                </div>
                <div class="form-group">
                <label for="alamat">Alamat</label>
                <input value="<?php echo e(old('alamat') ? old('alamat') : $kandidat->alamat); ?>" class="form-control <?php echo e($errors->first('alamat')
                    ? "is-invalid": ""); ?>" placeholder="Alamat" type="text" name="alamat"
                    id="alamat"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('alamat')); ?>

                    </div>
  
                </div>
                <div class="form-group">
                    <label for="telp">No Telpon</label>
                    <input value="<?php echo e(old('telp') ? old('telp') : $kandidat->telp); ?>" class="form-control <?php echo e($errors->first('telp')
                      ? "is-invalid": ""); ?>" placeholder="No Telpon" type="text" name="telp"
                      id="telp"/>
                      <div class="invalid-feedback">
                          <?php echo e($errors->first('telp')); ?>

                      </div>
  
                  </div>
                
                <div class="form-group">
                  <label for="foto">Foto</label>
                  <input value="<?php echo e(old('foto')); ?>" class="form-control <?php echo e($errors->first('foto')
                    ? "is-invalid": ""); ?>" type="file" name="foto"
                    id="foto"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('foto')); ?>

                    </div>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">ubah</button>
              </div>
            </form>
          </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>