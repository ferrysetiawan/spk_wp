<?php $__env->startSection('title', 'Ubah User'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Ubah User
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(Route('user.index')); ?>">Data User</a></li>
      <li class="active">Ubah User</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        
        <div class="box box-primary">
            <!-- form start -->
            <form enctype="multipart/form-data" class="bg-white shadow-sm p-3"
            action="<?php echo e(route('user.update', ['id'=>$user->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="PUT" name="_method">
              <div class="box-body">
                <div class="form-group">
                  <label for="name">Nama</label>
                  <input value="<?php echo e(old('name') ? old('name') : $user->name); ?>" class="form-control <?php echo e($errors->first('name')
                    ? "is-invalid": ""); ?>" placeholder="Full Name" type="text" name="name"
                    id="name"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>

                </div>
                <div class="form-group">
                  <label for="email">Alamat Email</label>
                  <input value="<?php echo e(old('email') ? old('email') : $user->email); ?>" class="form-control <?php echo e($errors->first('email')
                    ? "is-invalid": ""); ?>" placeholder="Email" type="email" name="email"
                    id="email"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>

                </div>
                <div class="form-group">
                  <label for="password">Password</label>
                  <input value="<?php echo e(old('password')); ?>" class="form-control <?php echo e($errors->first('password')
                    ? "is-invalid": ""); ?>" placeholder="password" type="password" name="password"
                    id="password"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('password')); ?>

                    </div>
                </div>
                <div class="form-group">
                  <label for="foto">Foto</label>
                  <input value="<?php echo e(old('foto')); ?>" class="form-control <?php echo e($errors->first('foto')
                    ? "is-invalid": ""); ?>" type="file" name="foto"
                    id="foto"/>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('foto')); ?>

                    </div>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">ubah</button>
              </div>
            </form>
          </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>