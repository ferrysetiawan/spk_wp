<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group has-feedback">
      <input id="email" type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
      <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      <?php if($errors->has('email')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('email')); ?></strong>
          </span>
      <?php endif; ?>
    </div>
    <div class="form-group has-feedback">
      <input id="password" type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Password">
      <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      <?php if($errors->has('password')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('password')); ?></strong>
          </span>
      <?php endif; ?>
    </div>
    <div class="row">
      <!-- /.col -->
      <div class="col-xs-12">
        <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
      </div>
      <!-- /.col -->
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>