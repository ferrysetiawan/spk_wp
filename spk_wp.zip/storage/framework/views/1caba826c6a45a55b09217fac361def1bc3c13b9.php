<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <!-- Main content -->
  <section class="content">
    <div class="box box-default">
      <div class="box-body">
        <div class="text-center">
          <br><br><br><br><br><br><br>
          <img src="<?php echo e(asset('storage/pcm.png')); ?>" width="250px" alt="logo pcm">
          <h2><b>SISTEM PENUNJANG KEPUTUSAN MENENTUKAN KARYAWAN TERBAIK<br>
          DENGAN PENDEKATAN METODE WEIGHTED PRODUCT<br>PADA PT. PELABUHAN CILEGON MANDIRI</b></h2>
          <br><br><br><br><br><br><br>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>