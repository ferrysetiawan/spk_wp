<?php $__env->startSection('title', 'Penilaian Kandidat'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Ubah Penilaian Kandidat
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(url('Nilai')); ?>">Data Penilaian Kandidat</a></li>
      <li class="active">Ubah Penilaian Kandidat</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        
        <div class="box box-primary">
            <div class="box-body">
                <form role="form" action="<?php echo e(route('nilai.update', ['id' => Request::segment(3)])); ?>" method="POST">
                    
                                <!-- text input -->
                                <?php echo csrf_field(); ?>
                                <?php if(!empty($kandidat)): ?>
                                <div class="form-group">
                                    <label for="mahasiswa">Nama Kandidat</label>
                                    <!-- <input type="hidden" name="mahasiswa_id" value="<?php echo e($kandidat->id); ?>"> -->
                                    <input type="text" class="form-control" value="<?php echo e($kandidat->nama); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <?php $__currentLoopData = $kandidat->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $krit = $kriteria[$key]; $krit_err = "kriteria_id[$krit->id]" ?>
                                    <?php if($krit->id == $value->kriteria_id): ?>
                                    <label for="<?php echo e($krit->kode); ?>"><?php echo e($krit->nama); ?></label>
                                    <input type="hidden" name="id_nilai[<?php echo e($value->id); ?>]" value="<?php echo e($value->id); ?>">
                                    <input type="text" class="form-control" name="<?php echo e($krit_err); ?>" value="<?php echo e($value->nilai); ?>">
                                    <?php elseif(empty($krit)): ?>
                                    <p>Fail</p>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php else: ?>
                                <div class="form-group text-center">
                                    Data Tidak Ditemukan
                                </div>
                                <?php endif; ?>
                    <div class="box-footer">
                        <?php if(!empty($kandidat)): ?>
                        <button type="submit" class="btn btn-primary">Update</button>
                        <?php else: ?>
                        <a href="<?php echo e(route('nilai')); ?>" class="btn btn-primary">
                            <i class="fas fa-arrow-left"></i>
                            Back
                        </a>
                        <?php endif; ?> 
                    </div>
                </form>
              <!-- /.box-body -->
            </div>
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>