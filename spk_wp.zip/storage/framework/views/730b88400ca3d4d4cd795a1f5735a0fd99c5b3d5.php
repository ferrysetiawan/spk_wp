<div id="sidebar" class="sidebar      h-sidebar                navbar-collapse collapse          ace-save-state">
    <script type="text/javascript">
        try{ace.settings.loadState('sidebar')}catch(e){}
    </script>
    <ul class="nav nav-list">
        <li class="<?php echo e(Request::is('home*') ? 'active open': ''); ?> hover">
            <a href="<?php echo e(url('/home')); ?>">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Dashboard </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="<?php echo e(Request::is('agen*') ? 'active open': ''); ?> hover">
            <a href="//">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Kriteria </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="<?php echo e(Request::is('jetty*') ? 'active open': ''); ?> hover">
            <a href="//">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Karyawan </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="<?php echo e(Request::is('jetty*') ? 'active open': ''); ?> hover">
            <a href="//">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Penilaian </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="<?php echo e(Request::is('user*') ? 'active open': ''); ?> hover">
            <a href="<?php echo e(route('user.index')); ?>">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Pengguna </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="<?php echo e(Request::is('j*') ? 'active open': ''); ?> hover">
            <a href="//">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Laporan </span>
            </a>

            <b class="arrow"></b>
        </li>
    </ul><!-- /.nav-list -->
</div>