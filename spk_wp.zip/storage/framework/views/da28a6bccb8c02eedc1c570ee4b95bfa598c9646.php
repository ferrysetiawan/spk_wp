<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
            <span class="bigger-120">
                Ferry Setiawan &copy; <?php echo date("Y"); ?>
            </span>
        </div>
    </div>
</div>