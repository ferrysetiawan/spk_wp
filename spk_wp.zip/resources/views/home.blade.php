@extends('layouts.global')
@section('title','Dashboard')

@section('content')
  <!-- Main content -->
  <section class="content">
    <div class="box box-default">
      <div class="box-body">
        <div class="text-center">
          <br><br><br><br><br><br><br>
          <img src="{{asset('storage/pcm.png')}}" width="250px" alt="logo pcm">
          <h2><b>SISTEM PENUNJANG KEPUTUSAN MENENTUKAN KARYAWAN TERBAIK<br>
          DENGAN PENDEKATAN METODE WEIGHTED PRODUCT<br>PADA PT. PELABUHAN CILEGON MANDIRI</b></h2>
          <br><br><br><br><br><br><br>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </section>
@endsection
